# drone detection > 2023-02-19 11:09pm
https://universe.roboflow.com/harun-yavuz-u94vy/drone-detection-kozki

Provided by a Roboflow user
License: CC BY 4.0

